#!/usr/bin/env node
/**
 * Benchmark Armyknife Protocol v1.0 — CLI entry
 * Autor concepto: Shane (especificacion) · implementacion esqueleto ejecutable
 */
import { runBenchmarkOrchestrator } from './engine/benchmark_orchestrator.js';
import { renderTreeAscii } from './ui/tree_renderer.js';

async function main() {
  const urls = process.argv.slice(2).filter((a) => !a.startsWith('-'));
  const targets =
    urls.length > 0
      ? urls.map((url, i) => ({ url, label: `Target_${i + 1}` }))
      : [{ url: 'https://example.com', label: 'example.com (demo)' }];

  console.error('[benchmark-armyknife] fetching', targets.map((t) => t.url).join(', '));

  const out = await runBenchmarkOrchestrator({
    websites: targets,
    preselectAll: false,
  });

  console.log('=== Markdown table ===\n');
  console.log(out.markdownTable);
  console.log('\n=== Tree sample (first URL) ===\n');
  if (out.results[0]) {
    console.log(renderTreeAscii(out.results[0].tree));
  }
  console.log('\n=== JSON export ===\n');
  console.log(out.json);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
