# Benchmark Armyknife Protocol v1.0

**Autor (concepto y arquitectura):** Shane  
**Código:** motor TypeScript ejecutable bajo `tools/benchmark-armyknife/`.

## Qué hace (v1)

- **Fetch** ligero (`fetch`, sin Puppeteer por defecto) + caché en memoria.
- **Parse** HTML → árbol heurístico (`cheerio`).
- **Scores:** power, popularity (stub + npm downloads opcional), performance (latencia), costo (heurística texto).
- **Total** con pesos 0.35 / 0.25 / 0.20 / 0.20.
- **Export:** tabla Markdown + JSON (`benchmark_results`, `selected_tree`, `meta`).
- **UI lógica:** `SelectionState` + filtro de árbol (checkboxes descritos en especificación).

## Comandos

```bash
cd tools/benchmark-armyknife
npm install
npm run build
node dist/index.js https://example.com
```

Si falla TLS (`unable to get local issuer certificate`), solo en entorno de laboratorio:

```bash
NODE_TLS_REJECT_UNAUTHORIZED=0 node dist/index.js https://example.com
```

## Especificación completa

Ver `SPEC_BENCHMARK_ARMYKNIFE_PROTOCOL_v1.md`.

## Tag

`[MOCKUP PURPOSE ONLY - NOT REAL DATA]`
